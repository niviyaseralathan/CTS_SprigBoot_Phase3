package com.springboot.beginner.restcontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.beginner.entity.FriendEntity;
import com.springboot.beginner.pojo.Friend;
import com.springboot.beginner.service.FriendService;
@RestController
public class FriendController {
	@Autowired
	private FriendService friendservice;
	
	@RequestMapping("/")
	public String welcome() {
		return "Welcome to Spring Boot Data !!!!";
	}
	@RequestMapping(value="/save",method=RequestMethod.POST)
	public void saveFriend(@RequestBody Friend friend) {
		System.out.println(friend.getLocation()+" "+friend.getName());
		friendservice.saveFriend(friend);
	}
	
	@RequestMapping("/all")
	public List<FriendEntity> getAllFriends() {
		return friendservice.getAllFriends();
	}
	
	@RequestMapping("/get/{myId}")
	public FriendEntity getFriendById(@PathVariable("myId") int id) {
		return friendservice.getFriendById(id);		
	}
	
	@RequestMapping("/del/{myId}")
	public List<FriendEntity> deleteFriendById(@PathVariable("myId") int id) {
		return friendservice.deleteFriendById(id);
	}
	
	//Update the existing data in the table
	//send id and friend pojo class
	@PostMapping("/update/{myId}")
	public List<FriendEntity> updateFriendById(@PathVariable("myId") int id, @RequestBody Friend friend) {
		return friendservice.updateFriendById(id, friend);
		
		
		
	}
	
	
}
package com.springboot.beginner.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springboot.beginner.entity.FriendEntity;

public interface FreindRepository extends JpaRepository<FriendEntity,Integer> {

}

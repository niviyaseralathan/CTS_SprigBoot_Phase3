package com.springboot.beginner.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.beginner.dao.FriendDAO;
import com.springboot.beginner.entity.FriendEntity;
import com.springboot.beginner.pojo.Friend;
@Service
public class FriendService {
	@Autowired
	private FriendDAO friendDao; 
	public List<FriendEntity> saveFriend(Friend friend) {
		return friendDao.saveProject(friend);
		
	}
	public List<FriendEntity> getAllFriends() {
		return friendDao.getAllFriends();
	}
	public FriendEntity getFriendById(int id) {
		// TODO Auto-generated method stub
		return friendDao.getFriendById(id);
		
	}
	public List<FriendEntity> deleteFriendById(int id) {
		return  friendDao.deleteFriendById(id);
		
	}
	public List<FriendEntity> updateFriendById(int id, Friend friend) {
	return friendDao.updateFriendById(id, friend);
		
		
		
	}

}

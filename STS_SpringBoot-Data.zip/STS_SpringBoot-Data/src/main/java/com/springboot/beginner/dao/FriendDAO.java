package com.springboot.beginner.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.springboot.beginner.entity.FriendEntity;
import com.springboot.beginner.pojo.Friend;
import com.springboot.beginner.repository.FreindRepository;
@Repository
public class FriendDAO {
	
	@Autowired
	private FreindRepository friendrepository;
	
	public List<FriendEntity> saveProject(Friend friend) {
		FriendEntity fe=new FriendEntity();
		
		fe.setName(friend.getName());
		fe.setLocation(friend.getLocation());
		friendrepository.save(fe);
		return friendrepository.findAll();
	}
	
	public List<FriendEntity> getAllFriends() {
		return friendrepository.findAll();
	}
	
	public FriendEntity getFriendById(int id) {
		//optional - used like when other case(Given i/p is not in table)
		return friendrepository.findById(id).get();
	}
	
	public List<FriendEntity> deleteFriendById(int id) {
		friendrepository.deleteById(id);
		return friendrepository.findAll();	
	}

	public List<FriendEntity> updateFriendById(int id, Friend friend) {
			
		FriendEntity fe = new FriendEntity();
		fe.setId(id);
		fe.setLocation(friend.getLocation());
		fe.setName(friend.getName());
		friendrepository.save(fe);
		friendrepository.saveAndFlush(fe);
		
		return friendrepository.findAll();
		
	}
	
	

}

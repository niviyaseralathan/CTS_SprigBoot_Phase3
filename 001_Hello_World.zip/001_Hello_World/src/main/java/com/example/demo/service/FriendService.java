package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.FriendDao;
import com.example.demo.pojo.Friend;

@Service("fs")
public class FriendService {

	@Autowired
	private FriendDao fD;
	
	public List<Friend> getAllFriends(){
		return fD.getAllFriends();
	}

	public Friend getFriendbyid(String id) {
		return fD.getFriendbyid(id);
		
		
	}
	
}

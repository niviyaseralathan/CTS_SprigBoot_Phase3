package com.example.demo.java;

import java.util.List;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.pojo.Friend;
import com.example.demo.service.FriendService;

@RestController
@RequestMapping("/api")
public class WelcomeController {
	
	@Autowired
	private FriendService fs;	
	
	@GetMapping("/all")
	public  List<Friend> ListF1() {
		return fs.getAllFriends();
	}
	
	@RequestMapping(value="/get/{id}")
	public Friend getFriendbyid(@PathVariable String id) {
		return fs.getFriendbyid(id);
		
	}
	

	
	
	
	
	
	
//	@RequestMapping(value="/wel", method=RequestMethod.POST)
//	public String wel1() {
//		return "Hello Everyone - Check post!!!";
//	}
//
//	@RequestMapping(value="/wel", method=RequestMethod.GET)
//	public String wel2() {
//		return "Hello Everyone - Check get!!!";
//	}
//	
//	@RequestMapping(value="/wel", method=RequestMethod.PUT)
//	public String wel3() {
//		return "Hello Everyone - Check Put!!!";
//	}
//	
//	@DeleteMapping(value="/wel")
//	public String wel4() {
//		return "Hello Everyone - Check Delete!!!";
//	}
//	
//	@GetMapping("/all")
//	public List<Friend> listFriends() {		
//		
//		List<Friend> fr = new ArrayList<>();
//		
//		//instance
//		Friend f1 = new Friend();
//		Friend f2 = new Friend();
//		
//		f1.setAge(27);
//		f1.setName("Nivi");
//						
//		f2.setAge(21);
//		f2.setName("Nivas");
//						
//		//add it to fr collection
//		fr.add(f1);
//		fr.add(f2);
//		
//		return fr;
//		
//		
//		
//		
//	}
	
}
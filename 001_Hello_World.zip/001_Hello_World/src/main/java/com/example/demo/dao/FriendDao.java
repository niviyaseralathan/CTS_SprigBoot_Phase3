package com.example.demo.dao;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.pojo.Friend;

@Repository
public class FriendDao {

	private List<Friend> fr = new ArrayList<>(Arrays.asList(
			
			new Friend("Raf",21,"1"),
			new Friend("Nivi",21,"2"),
			new Friend("Check",21,"3"),
			new Friend("Success",21,"4")
			));
	
	public List<Friend> getAllFriends() {
		
//		List<Friend> fr = new ArrayList<>();
//		
//		//instance
//		Friend f1 = new Friend();
//		Friend f2 = new Friend();
//		
//		f1.setAge(27);
//		f1.setName("Nivi");
//						
//		f2.setAge(21);
//		f2.setName("Nivas");
//						
//		//add it to fr collection
//		fr.add(f1);
//		fr.add(f2);
		
		return fr;	
		
		
	}

	public Friend getFriendbyid(String id) {
		return fr.stream().filter((f)->f.getId().equals(id)).findFirst().get();	
	}
	
	
}
